using System;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

// RunAcrylic v3 - tray companion for PowerToys Run (Windows 11).
//
// Started by the RunAcrylic PowerToys Run plugin:  RunAcrylic.exe --parent <PowerLauncher pid>
// It lives exactly as long as that PowerToys Run process, styles the Run window event-driven
// (no polling) and restores the window when it exits.
//
// By hand:  RunAcrylic.exe [--parent <pid>] [off | acrylic | mica | clear:<10-100>]
// Log:      %LOCALAPPDATA%\RunAcrylic\RunAcrylic.log
// Style:    %LOCALAPPDATA%\RunAcrylic\style.txt

internal static class Program
{
    private const string LauncherProcess = "PowerToys.PowerLauncher";

    [STAThread]
    private static void Main(string[] args)
    {
        Mutex? mutex = null;
        bool owned = false;
        try
        {
            int parentPid = 0;
            string? styleArg = null;
            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "--parent" && i + 1 < args.Length && int.TryParse(args[i + 1], out int p))
                {
                    parentPid = p;
                    i++;
                }
                else
                {
                    styleArg = args[i];
                }
            }

            if (parentPid == 0) parentPid = FindLauncherPid();
            if (parentPid == 0) return;   // PowerToys Run is not running: nothing to attach to (silent)

            // One companion per PowerToys Run process. A restarted PowerToys has a new pid, so the
            // new companion never collides with the old one that is still shutting down.
            mutex = new Mutex(true, @"Local\RunAcrylic_" + parentPid, out owned);
            if (!owned) return;

            Process? parent = OpenLauncher(parentPid);
            if (parent == null) return;   // gone already, or not PowerToys Run

            Log.Reset();
            Log.Write("started: pid " + Environment.ProcessId + ", parent " + parentPid
                      + ", OS " + Environment.OSVersion.Version + ", .NET " + Environment.Version
                      + ", elevated=" + IsElevated());
            if (Environment.OSVersion.Version.Build < 22621)
                Log.Write("note: DWM backdrop (acrylic/mica) needs Windows 11 22H2 or newer; see-through may still work");

            StyleSpec style = StyleSpec.Parse(styleArg ?? StyleSpec.LoadSaved() ?? "clear:75");

            // Same as the generated ApplicationConfiguration.Initialize(), but without depending on a
            // source-generated class whose namespace follows the project's RootNamespace.
            Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new TrayContext(style, parent));
        }
        catch (Exception ex)
        {
            Log.Write("CRASH: " + ex);
        }
        finally
        {
            if (mutex != null)
            {
                if (owned) { try { mutex.ReleaseMutex(); } catch { } }
                mutex.Dispose();
            }
        }
    }

    private static int FindLauncherPid()
    {
        int pid = 0;
        foreach (Process p in Process.GetProcessesByName(LauncherProcess))
        {
            using (p) { if (pid == 0) pid = p.Id; }
        }
        return pid;
    }

    /// <summary>Opens the process and checks it really is PowerToys Run (guards against pid reuse / typos).</summary>
    private static Process? OpenLauncher(int pid)
    {
        Process? p = null;
        try
        {
            p = Process.GetProcessById(pid);
            if (string.Equals(p.ProcessName, LauncherProcess, StringComparison.OrdinalIgnoreCase)) return p;
            Log.Write("pid " + pid + " is '" + p.ProcessName + "', not PowerToys Run - exiting");
        }
        catch (ArgumentException) { /* no such process any more */ }
        catch (Exception ex) { Log.Write("cannot open pid " + pid + ": " + ex.Message); }
        p?.Dispose();
        return null;
    }

    private static bool IsElevated()
    {
        try
        {
            using var id = System.Security.Principal.WindowsIdentity.GetCurrent();
            return new System.Security.Principal.WindowsPrincipal(id)
                .IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
        }
        catch { return false; }
    }
}
