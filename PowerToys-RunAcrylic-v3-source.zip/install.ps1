<#
.SYNOPSIS
  Builds and installs RunAcrylic v3 (tray companion + PowerToys Run plugin).

.EXAMPLE
  .\install.ps1            # PowerToys must be closed
  .\install.ps1 -Force     # closes PowerToys for you and starts it again afterwards
#>
[CmdletBinding()]
param(
    [ValidateSet('x64', 'ARM64')]
    [string]$Platform = 'x64',

    # Close PowerToys automatically (and start it again when done).
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot

function Step([string]$text) { Write-Host ''; Write-Host "== $text" -ForegroundColor Cyan }
function Ok([string]$text)   { Write-Host "   OK  $text" -ForegroundColor Green }
function Warn([string]$text) { Write-Host "   !!  $text" -ForegroundColor Yellow }

try {
    $rid = if ($Platform -eq 'ARM64') { 'win-arm64' } else { 'win-x64' }
    $pluginRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\PowerToys\PowerToys Run\Plugins'
    $dest = Join-Path $pluginRoot 'RunAcrylic'

    # ------------------------------------------------------------------ 1. prerequisites
    Step 'Checking prerequisites'
    if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
        throw 'dotnet was not found. Install the .NET 10 SDK from https://dotnet.microsoft.com/download'
    }
    $majors = @(& dotnet --list-sdks | ForEach-Object { [int]($_.Split('.')[0]) })
    if ($majors.Count -eq 0 -or (($majors | Measure-Object -Maximum).Maximum -lt 10)) {
        $found = (& dotnet --list-sdks) -join '; '
        throw "The .NET 10 SDK is required (RunAcrylic.exe targets net10.0-windows). Found: $found"
    }
    Ok '.NET 10 SDK found'
    if (-not (Test-Path (Join-Path $env:LOCALAPPDATA 'Microsoft\PowerToys'))) {
        throw 'PowerToys does not look installed (no %LOCALAPPDATA%\Microsoft\PowerToys).'
    }

    # ------------------------------------------------------------------ 2. PowerToys must not hold the plugin files
    Step 'PowerToys'
    $ptExe = $null
    $running = @(Get-Process -Name 'PowerToys*' -ErrorAction SilentlyContinue)
    if ($running.Count -gt 0) {
        if (-not $Force) {
            throw 'PowerToys is running. Exit it (tray icon > Exit) and run again, or run: .\install.ps1 -Force'
        }
        $main = $running | Where-Object { $_.ProcessName -eq 'PowerToys' } | Select-Object -First 1
        if ($main) { try { $ptExe = $main.Path } catch { } }
        try {
            $running | Stop-Process -Force
        } catch {
            throw 'Could not close PowerToys (it probably runs as administrator). Close it manually or start this script from an administrator PowerShell.'
        }
        $i = 0
        while ((Get-Process -Name 'PowerToys*' -ErrorAction SilentlyContinue) -and $i -lt 30) { Start-Sleep -Milliseconds 500; $i++ }
        Ok 'PowerToys closed'
    } else {
        Ok 'PowerToys is not running'
    }

    # ------------------------------------------------------------------ 3. stop and clean any old RunAcrylic
    Step 'Removing old RunAcrylic leftovers'
    Get-Process -Name 'RunAcrylic' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 400

    # old autostart entry from the first version
    $runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    if (Get-ItemProperty -Path $runKey -Name 'RunAcrylic' -ErrorAction SilentlyContinue) {
        Remove-ItemProperty -Path $runKey -Name 'RunAcrylic' -ErrorAction SilentlyContinue
        Ok 'removed old autostart entry'
    }
    # old stand-alone exe (v1 location). Our log and style.txt live in the same folder and are kept.
    $oldExe = Join-Path $env:LOCALAPPDATA 'RunAcrylic\RunAcrylic.exe'
    if (Test-Path $oldExe) { Remove-Item $oldExe -Force; Ok 'removed old RunAcrylic.exe from %LOCALAPPDATA%\RunAcrylic' }
    # old separate Keywords plugin (only if it is ours)
    $oldKw = Join-Path $pluginRoot 'Keywords'
    if (Test-Path (Join-Path $oldKw 'Community.PowerToys.Run.Plugin.Keywords.dll')) {
        Remove-Item $oldKw -Recurse -Force; Ok 'removed old Keywords plugin (its job is inside this plugin now)'
    }
    if (Test-Path $dest) { Remove-Item $dest -Recurse -Force; Ok 'removed previous RunAcrylic plugin folder' }

    # ------------------------------------------------------------------ 4. build
    Step "Building RunAcrylic.exe ($rid)"
    foreach ($d in @('RunAcrylic\bin', 'RunAcrylic\obj', 'Plugin\bin', 'Plugin\obj', '_out')) {
        $p = Join-Path $root $d
        if (Test-Path $p) { Remove-Item $p -Recurse -Force }
    }
    $appOut = Join-Path $root '_out\app'
    & dotnet publish (Join-Path $root 'RunAcrylic\RunAcrylic.csproj') -c Release -r $rid --self-contained false -o $appOut --nologo -v minimal
    if ($LASTEXITCODE -ne 0) { throw "dotnet publish failed for RunAcrylic.exe (exit code $LASTEXITCODE). See the messages above." }
    $exe = Join-Path $appOut 'RunAcrylic.exe'
    if (-not (Test-Path $exe)) { throw "RunAcrylic.exe was not produced in $appOut" }
    Ok ('RunAcrylic.exe built (' + [math]::Round((Get-Item $exe).Length / 1KB) + ' KB)')

    Step "Building plugin ($Platform)"
    & dotnet build (Join-Path $root 'Plugin\Community.PowerToys.Run.Plugin.RunAcrylic.csproj') -c Release "-p:Platform=$Platform" --nologo -v minimal
    if ($LASTEXITCODE -ne 0) { throw "dotnet build failed for the plugin (exit code $LASTEXITCODE). See the messages above." }
    $built = Get-ChildItem -Path (Join-Path $root 'Plugin\bin') -Recurse -Filter 'Community.PowerToys.Run.Plugin.RunAcrylic.dll' |
             Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $built) { throw 'Plugin DLL was not produced.' }
    $pluginOut = $built.DirectoryName
    Ok "plugin built: $($built.FullName)"

    # ------------------------------------------------------------------ 5. install
    Step 'Installing'
    New-Item -ItemType Directory -Path $dest -Force | Out-Null
    foreach ($f in @('Community.PowerToys.Run.Plugin.RunAcrylic.dll', 'Community.PowerToys.Run.Plugin.RunAcrylic.deps.json', 'plugin.json')) {
        $src = Join-Path $pluginOut $f
        if (Test-Path $src) { Copy-Item $src $dest -Force }
        elseif ($f -ne 'Community.PowerToys.Run.Plugin.RunAcrylic.deps.json') { throw "Missing build output: $f" }
    }
    Copy-Item (Join-Path $pluginOut 'Images') (Join-Path $dest 'Images') -Recurse -Force
    Copy-Item $exe $dest -Force

    foreach ($f in @('Community.PowerToys.Run.Plugin.RunAcrylic.dll', 'plugin.json', 'RunAcrylic.exe', 'Images\icon.png')) {
        if (-not (Test-Path (Join-Path $dest $f))) { throw "Install verification failed: $f is not in $dest" }
    }
    Ok "installed to $dest"

    # ------------------------------------------------------------------ 6. restart PowerToys
    Step 'Finishing'
    if (-not $ptExe) {
        foreach ($c in @((Join-Path $env:LOCALAPPDATA 'PowerToys\PowerToys.exe'), (Join-Path $env:ProgramFiles 'PowerToys\PowerToys.exe'))) {
            if (Test-Path $c) { $ptExe = $c; break }
        }
    }
    if ($Force -and $ptExe) {
        Start-Process $ptExe
        Ok 'PowerToys started again'
    } else {
        Warn 'Start PowerToys now.'
    }

    Write-Host ''
    Write-Host 'Done. After PowerToys is up, a RunAcrylic icon appears in the tray within a second or two.' -ForegroundColor Green
    Write-Host 'Right-click it to choose Off / Acrylic / Mica / See-through. Log: %LOCALAPPDATA%\RunAcrylic\RunAcrylic.log'
}
catch {
    Write-Host ''
    Write-Host "INSTALL FAILED: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
