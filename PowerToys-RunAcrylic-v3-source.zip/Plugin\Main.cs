using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using Wox.Plugin;

namespace Community.PowerToys.Run.Plugin.RunAcrylic
{
    /// <summary>
    /// 1) Init(): starts RunAcrylic.exe (same folder) and tells it the PowerToys Run process id, so the
    ///    tray companion lives and dies with PowerToys Run - no autostart entry, no polling.
    /// 2) "kw": lists the action keywords of all plugins on demand (instead of the always-on hint list).
    /// </summary>
    public class Main : IPlugin
    {
        public static string PluginID => "BA3BB56F958946819D474CD152EE226E";

        public string Name => "RunAcrylic";
        public string Description => "Starts the RunAcrylic tray companion with PowerToys Run. Type kw to list plugin keywords.";

        private PluginInitContext _context;
        private string _icon = string.Empty;
        private volatile string _launchProblem;

        public void Init(PluginInitContext context)
        {
            _context = context;
            string dir = string.Empty;
            try { dir = context?.CurrentPluginMetadata?.PluginDirectory ?? string.Empty; } catch { }
            _icon = Path.Combine(dir, "Images", "icon.png");

            int pid = Environment.ProcessId;            // = the PowerToys Run process
            Task.Run(() => StartCompanion(dir, pid));   // off the startup path: Run is never delayed
        }

        private void StartCompanion(string dir, int pid)
        {
            try
            {
                string exe = Path.Combine(dir, "RunAcrylic.exe");
                if (!File.Exists(exe))
                {
                    _launchProblem = "RunAcrylic.exe is missing in the plugin folder - re-run install.ps1";
                    return;
                }

                var psi = new ProcessStartInfo(exe)
                {
                    Arguments = "--parent " + pid,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    WorkingDirectory = dir
                };
                // PowerToys is self-contained and sets DOTNET_* variables; they would stop our
                // framework-dependent exe from finding the installed .NET runtime.
                foreach (string v in new[] { "DOTNET_ROOT", "DOTNET_ROOT(x86)", "DOTNET_MULTILEVEL_LOOKUP", "DOTNET_ROOT_X64", "DOTNET_ROOT_ARM64" })
                    psi.Environment.Remove(v);

                using (Process.Start(psi)) { }
                // A second start (PowerToys Run reload) is harmless: the exe holds a per-pid mutex and quits.
            }
            catch (Exception ex)
            {
                _launchProblem = "Could not start RunAcrylic.exe: " + ex.Message;
            }
        }

        public List<Result> Query(Query query)
        {
            var results = new List<Result>();
            string problem = _launchProblem;
            if (problem != null)
            {
                results.Add(new Result
                {
                    Title = "RunAcrylic: " + problem,
                    SubTitle = "Tray companion is not running",
                    IcoPath = _icon,
                    Score = 10000
                });
            }

            if (_context == null) return results;

            string filter = (query?.Search ?? string.Empty).Trim();
            List<PluginPair> plugins;
            try { plugins = _context.API.GetAllPlugins(); }
            catch { return results; }

            var rows = new List<(string Keyword, string Name, string Desc)>();
            foreach (PluginPair p in plugins)
            {
                try
                {
                    string kw = p.Metadata?.ActionKeyword;
                    if (string.IsNullOrWhiteSpace(kw) || kw == "*") continue;
                    if (p.Metadata.Disabled) continue;
                    rows.Add((kw, p.Metadata.Name ?? string.Empty, p.Plugin?.Description ?? string.Empty));
                }
                catch { /* a misbehaving plugin must not break the list */ }
            }
            rows.Sort((a, b) => string.Compare(a.Keyword, b.Keyword, StringComparison.OrdinalIgnoreCase));

            int score = 5000;
            foreach (var r in rows)
            {
                if (filter.Length > 0
                    && r.Keyword.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0
                    && r.Name.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0
                    && r.Desc.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0)
                    continue;

                string keyword = r.Keyword;
                results.Add(new Result
                {
                    Title = keyword + "    " + r.Name,
                    SubTitle = r.Desc,
                    IcoPath = _icon,
                    Score = score--,
                    Action = _ =>
                    {
                        _context.API.ChangeQuery(keyword + " ", true);   // put the keyword in the box
                        return false;                                    // keep Run open
                    }
                });
            }
            return results;
        }
    }
}
