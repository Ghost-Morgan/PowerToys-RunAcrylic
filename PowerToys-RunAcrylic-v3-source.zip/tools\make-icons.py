"""Regenerates RunAcrylic/RunAcrylic.ico and Plugin/Images/icon.png (needs: pip install pillow)."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parent.parent
S = 512  # draw large, downsample for crisp small sizes


def glass_icon() -> Image.Image:
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))

    # back pane: deep blue rounded square
    back = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(back)
    d.rounded_rectangle((40, 40, 372, 372), radius=70, fill=(40, 90, 200, 255))
    img.alpha_composite(back)

    # front pane: translucent frosted rounded square, offset down-right
    front = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(front)
    d.rounded_rectangle((140, 140, 472, 472), radius=70, fill=(190, 225, 255, 175),
                        outline=(255, 255, 255, 230), width=10)
    # soft top highlight
    hi = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(hi).rounded_rectangle((160, 160, 452, 270), radius=50, fill=(255, 255, 255, 70))
    front.alpha_composite(hi.filter(ImageFilter.GaussianBlur(6)))
    img.alpha_composite(front)
    return img


def main() -> None:
    icon = glass_icon()
    ico_path = ROOT / "RunAcrylic" / "RunAcrylic.ico"
    png_path = ROOT / "Plugin" / "Images" / "icon.png"
    ico_path.parent.mkdir(parents=True, exist_ok=True)
    png_path.parent.mkdir(parents=True, exist_ok=True)
    icon.save(ico_path, format="ICO", sizes=[(16, 16), (20, 20), (24, 24), (32, 32), (40, 40), (48, 48), (64, 64), (128, 128), (256, 256)])
    icon.resize((256, 256), Image.LANCZOS).save(png_path, format="PNG")
    print("wrote", ico_path, "and", png_path)


if __name__ == "__main__":
    main()
