<#
.SYNOPSIS
  Removes RunAcrylic completely and gives PowerToys Run its normal look back.

.EXAMPLE
  .\uninstall.ps1 -Force          # closes PowerToys, removes everything, starts PowerToys again
  .\uninstall.ps1 -KeepSettings   # keep style.txt and the log
#>
[CmdletBinding()]
param(
    [switch]$Force,
    [switch]$KeepSettings
)

$ErrorActionPreference = 'Stop'

function Ok([string]$text)   { Write-Host "   OK  $text" -ForegroundColor Green }

try {
    $pluginRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\PowerToys\PowerToys Run\Plugins'
    $dest = Join-Path $pluginRoot 'RunAcrylic'
    $ptExe = $null

    $running = @(Get-Process -Name 'PowerToys*' -ErrorAction SilentlyContinue)
    if ($running.Count -gt 0) {
        if (-not $Force) { throw 'PowerToys is running. Exit it first, or run: .\uninstall.ps1 -Force' }
        $main = $running | Where-Object { $_.ProcessName -eq 'PowerToys' } | Select-Object -First 1
        if ($main) { try { $ptExe = $main.Path } catch { } }
        try { $running | Stop-Process -Force } catch { throw 'Could not close PowerToys (administrator?). Close it manually.' }
        $i = 0
        while ((Get-Process -Name 'PowerToys*' -ErrorAction SilentlyContinue) -and $i -lt 30) { Start-Sleep -Milliseconds 500; $i++ }
        Ok 'PowerToys closed'
    }

    Get-Process -Name 'RunAcrylic' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 400

    if (Test-Path $dest) { Remove-Item $dest -Recurse -Force; Ok 'removed plugin folder' }

    $oldKw = Join-Path $pluginRoot 'Keywords'
    if (Test-Path (Join-Path $oldKw 'Community.PowerToys.Run.Plugin.Keywords.dll')) { Remove-Item $oldKw -Recurse -Force; Ok 'removed old Keywords plugin' }

    $runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    if (Get-ItemProperty -Path $runKey -Name 'RunAcrylic' -ErrorAction SilentlyContinue) {
        Remove-ItemProperty -Path $runKey -Name 'RunAcrylic' -ErrorAction SilentlyContinue; Ok 'removed old autostart entry'
    }

    $data = Join-Path $env:LOCALAPPDATA 'RunAcrylic'
    if (Test-Path $data) {
        if ($KeepSettings) {
            $old = Join-Path $data 'RunAcrylic.exe'
            if (Test-Path $old) { Remove-Item $old -Force }
        } else {
            Remove-Item $data -Recurse -Force; Ok 'removed %LOCALAPPDATA%\RunAcrylic (style + log)'
        }
    }

    if ($Force -and $ptExe) { Start-Process $ptExe; Ok 'PowerToys started again' }
    Write-Host 'RunAcrylic removed. PowerToys Run has its default look again.' -ForegroundColor Green
}
catch {
    Write-Host "UNINSTALL FAILED: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
