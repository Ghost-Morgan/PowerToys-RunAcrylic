using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

/// <summary>
/// Tray icon + styling engine. Everything here runs on the UI thread; the only calls that arrive on
/// other threads (Process.Exited, SystemEvents.*) are posted to the UI thread first.
///
/// Design rules (why it is light and does not lag):
///  - No polling. Window events (WinEvent hook, filtered to the PowerToys Run process) drive everything.
///  - A window is styled once. Later events only READ the current backdrop (one cheap call) and re-apply
///    only if PowerToys put its own backdrop back. So opening Run never causes extra recomposition.
///  - Styling happens while the window is hidden (CREATE/NAMECHANGE/HIDE), so there is no unstyled flash.
///  - The companion exits by itself the moment PowerToys Run exits, restoring the window first.
/// </summary>
internal sealed class TrayContext : ApplicationContext
{
    // Window title seen on this machine; other PowerToys builds use "PowerToys Run".
    private const string TitleA = "PowerToys.PowerLauncher";
    private const string TitleB = "PowerToys Run";

    private const uint TintRgb = 0x202020;   // dark grey tint behind the See-through styles
    private const int MaxFailures = 3;       // stop retrying a window that keeps rejecting us

    private sealed class WinState
    {
        public int Orig;                  // backdrop before we touched the window (for restore)
        public int Gen = -1;              // style generation last applied
        public int AppliedBackdrop = -1;  // what we set, to detect PowerToys resetting it
        public int Failures;
        public bool Extended;             // DwmExtendFrameIntoClientArea done
        public bool AccentOn;             // accent tint currently set by us
    }

    private readonly NotifyIcon _tray;
    private readonly Icon _icon;
    private readonly Control _ui;                       // marshals other-thread callbacks to the UI thread
    private readonly Process _parent;
    private readonly uint _parentPid;
    private readonly List<ToolStripMenuItem> _styleItems = new List<ToolStripMenuItem>();
    private readonly HashSet<IntPtr> _targets = new HashSet<IntPtr>();
    private readonly Dictionary<IntPtr, WinState> _state = new Dictionary<IntPtr, WinState>();
    private readonly Native.WinEventProc _hookProc;     // field on purpose: must outlive the hooks
    private readonly StringBuilder _title = new StringBuilder(256);

    private IntPtr _hookLife;      // CREATE..HIDE
    private IntPtr _hookName;      // NAMECHANGE
    private System.Windows.Forms.Timer? _watchdog;   // only if the process-exit event cannot be armed
    private System.Windows.Forms.Timer? _poll;       // only if the WinEvent hooks cannot be installed
    private System.Windows.Forms.Timer? _settle;     // two verify passes after start, then gone
    private System.Windows.Forms.Timer? _debounce;   // coalesces theme / resume / unlock bursts
    private int _settleStep;
    private int _gen;               // bumped to force a re-apply on the next ensure
    private bool _pendingForce;
    private bool _exiting;
    private bool _degraded;         // see-through rejected by Windows -> Acrylic fallback in use
    private bool _failed;           // something could not be applied (shown in the tooltip)
    private StyleSpec _style;

    public TrayContext(StyleSpec initial, Process parent)
    {
        _style = initial;
        _parent = parent;
        _parentPid = (uint)parent.Id;

        _ui = new Control();
        _ = _ui.Handle;   // create the handle now, on the UI thread

        // ---- tray menu ----
        var menu = new ContextMenuStrip();
        menu.Items.Add(new ToolStripMenuItem("RunAcrylic - PowerToys Run style") { Enabled = false });
        menu.Items.Add(new ToolStripSeparator());
        AddStyle(menu, "off");
        AddStyle(menu, "acrylic");
        AddStyle(menu, "mica");
        foreach (int pct in new[] { 90, 75, 60, 40, 25 }) AddStyle(menu, "clear:" + pct);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Re-apply now", null, (_, _) => { _gen++; ScanAndApply(); });
        menu.Items.Add("Open log", null, (_, _) => OpenLog());
        menu.Items.Add("Quit (comes back with PowerToys Run)", null, (_, _) => ExitApp());
        RefreshChecks();

        _icon = LoadIcon();
        _tray = new NotifyIcon { Icon = _icon, Text = TrayText(), ContextMenuStrip = menu, Visible = true };

        // ---- lifetime: follow PowerToys Run ----
        try
        {
            _parent.EnableRaisingEvents = true;
            _parent.Exited += (_, _) => PostToUi(ExitApp);
            if (_parent.HasExited) PostToUi(ExitApp);
        }
        catch (Exception ex)
        {
            Log.Write("cannot watch parent exit, using 3 s fallback check: " + ex.Message);
            _watchdog = new System.Windows.Forms.Timer { Interval = 3000 };
            _watchdog.Tick += (_, _) => { if (!ParentAlive()) ExitApp(); };
            _watchdog.Start();
        }

        // ---- styling: event driven ----
        _hookProc = OnWinEvent;
        _hookLife = Native.SetWinEventHook(Native.EVENT_OBJECT_CREATE, Native.EVENT_OBJECT_HIDE, IntPtr.Zero,
            _hookProc, _parentPid, 0, Native.WINEVENT_OUTOFCONTEXT);
        _hookName = Native.SetWinEventHook(Native.EVENT_OBJECT_NAMECHANGE, Native.EVENT_OBJECT_NAMECHANGE, IntPtr.Zero,
            _hookProc, _parentPid, 0, Native.WINEVENT_OUTOFCONTEXT);
        Log.Write("tray ready, style=" + _style.Name + ", hooks=" + (_hookLife != IntPtr.Zero) + "/" + (_hookName != IntPtr.Zero));

        if (_hookLife == IntPtr.Zero)
        {
            // Last-resort fallback so the effect still works: slow verify-only scan.
            Log.Write("WinEvent hook failed - falling back to a 500 ms verify scan");
            _poll = new System.Windows.Forms.Timer { Interval = 500 };
            _poll.Tick += (_, _) => ScanAndApply();
            _poll.Start();
        }

        ScanAndApply();   // the window usually exists already (PowerToys creates it hidden at startup)

        // PowerToys may set its own backdrop a moment after the window exists; verify twice, then stop.
        _settle = new System.Windows.Forms.Timer { Interval = 1200 };
        _settle.Tick += (_, _) =>
        {
            ScanAndApply();
            if (++_settleStep == 1) { _settle!.Interval = 3500; return; }
            _settle!.Stop();
            _settle.Dispose();
            _settle = null;
            Native.TrimWorkingSet();   // give back start-up memory once everything is settled
        };
        _settle.Start();

        SystemEvents.UserPreferenceChanged += OnUserPreferenceChanged;
        SystemEvents.PowerModeChanged += OnPowerModeChanged;
        SystemEvents.SessionSwitch += OnSessionSwitch;
    }

    // =========================================================================================
    //  events
    // =========================================================================================

    private void OnWinEvent(IntPtr hook, uint evt, IntPtr hwnd, int idObject, int idChild, uint thread, uint time)
    {
        if (_exiting || hwnd == IntPtr.Zero || idObject != Native.OBJID_WINDOW || idChild != 0) return;
        try
        {
            if (evt == Native.EVENT_OBJECT_DESTROY) { Forget(hwnd); return; }
            if (IsTarget(hwnd)) Ensure(hwnd);
        }
        catch (Exception ex) { Log.Write("event error: " + ex.Message); }
    }

    // Windows theme / accent colour change: PowerToys re-sets its own backdrop then, so we follow.
    private void OnUserPreferenceChanged(object? sender, UserPreferenceChangedEventArgs e)
    {
        if (e.Category == UserPreferenceCategory.General || e.Category == UserPreferenceCategory.Color
            || e.Category == UserPreferenceCategory.VisualStyle || e.Category == UserPreferenceCategory.Window)
            PostToUi(() => ScheduleRefresh(force: true, delayMs: 800));
    }

    private void OnPowerModeChanged(object? sender, PowerModeChangedEventArgs e)
    {
        if (e.Mode == PowerModes.Resume) PostToUi(() => ScheduleRefresh(force: false, delayMs: 1500));
    }

    private void OnSessionSwitch(object? sender, SessionSwitchEventArgs e)
    {
        if (e.Reason == SessionSwitchReason.SessionUnlock || e.Reason == SessionSwitchReason.ConsoleConnect
            || e.Reason == SessionSwitchReason.RemoteConnect)
            PostToUi(() => ScheduleRefresh(force: false, delayMs: 1500));
    }

    /// <summary>One shared timer: a burst of events turns into a single pass.</summary>
    private void ScheduleRefresh(bool force, int delayMs)
    {
        if (_exiting) return;
        _pendingForce |= force;
        if (_debounce == null)
        {
            _debounce = new System.Windows.Forms.Timer();
            _debounce.Tick += (_, _) =>
            {
                _debounce!.Stop();
                if (_exiting) return;
                if (_pendingForce) { _gen++; _pendingForce = false; }
                ScanAndApply();
            };
        }
        _debounce.Stop();
        _debounce.Interval = delayMs;
        _debounce.Start();
    }

    private void PostToUi(Action action)
    {
        try
        {
            if (!_exiting && _ui.IsHandleCreated && !_ui.IsDisposed) _ui.BeginInvoke(action);
        }
        catch { /* shutting down */ }
    }

    // =========================================================================================
    //  finding and styling the Run window
    // =========================================================================================

    private void Forget(IntPtr hwnd)
    {
        _targets.Remove(hwnd);
        _state.Remove(hwnd);
    }

    private bool IsTarget(IntPtr hwnd)
    {
        if (_targets.Contains(hwnd)) return true;

        Native.GetWindowThreadProcessId(hwnd, out uint pid);
        if (pid != _parentPid) return false;

        _title.Clear();
        Native.GetWindowText(hwnd, _title, _title.Capacity);
        string title = _title.ToString();
        if (title != TitleA && title != TitleB) return false;

        _targets.Add(hwnd);
        Log.Write("found Run window 0x" + hwnd.ToString("X"));
        return true;
    }

    private void ScanAndApply()
    {
        if (_exiting) return;
        try
        {
            Native.EnumWindows((h, _) =>
            {
                try { if (IsTarget(h)) Ensure(h); }
                catch (Exception ex) { Log.Write("scan item error: " + ex.Message); }
                return true;
            }, IntPtr.Zero);
        }
        catch (Exception ex) { Log.Write("scan error: " + ex.Message); }
    }

    /// <summary>Make sure this window carries the current style. Cheap when nothing changed.</summary>
    private void Ensure(IntPtr hwnd)
    {
        if (_style.IsOff) return;
        if (!Native.IsWindow(hwnd)) { Forget(hwnd); return; }

        if (!_state.TryGetValue(hwnd, out WinState? st))
        {
            int cur = Native.GetBackdrop(hwnd);
            st = new WinState { Orig = cur >= 0 ? cur : 0 };   // 0 = "let Windows decide"
            _state[hwnd] = st;
            Log.Write("original backdrop of 0x" + hwnd.ToString("X") + " = " + cur);
        }

        bool needs = st.Gen != _gen;
        if (!needs && st.Failures < MaxFailures)
        {
            // Already styled by us. Only re-apply if PowerToys put its own backdrop back.
            int cur = Native.GetBackdrop(hwnd);
            needs = cur >= 0 && cur != st.AppliedBackdrop;   // cur < 0: cannot tell -> leave alone
            if (needs) Log.Write("backdrop of 0x" + hwnd.ToString("X") + " was reset to " + cur + " -> re-applying");
        }
        if (!needs) return;
        if (st.Gen == _gen && st.Failures >= MaxFailures) return;   // gave up until style change / Re-apply

        Apply(hwnd, st);
    }

    private void Apply(IntPtr hwnd, WinState st)
    {
        if (!st.Extended)
        {
            var m = new Native.MARGINS { Left = -1, Right = -1, Top = -1, Bottom = -1 };
            Native.DwmExtendFrameIntoClientArea(hwnd, ref m);   // lets the backdrop/tint show through the client area
            st.Extended = true;
        }

        bool ok;
        int applied;

        if (_style.IsClear && !_degraded)
        {
            // See-through: no DWM backdrop, translucent dark tint instead.
            int hrBackdrop = Native.SetBackdrop(hwnd, 1);
            uint color = ((uint)_style.Opacity << 24) | TintRgb;
            bool accentOk = Native.SetAccent(hwnd, Native.ACCENT_ENABLE_TRANSPARENTGRADIENT, color, out int err);
            if (accentOk)
            {
                st.AccentOn = true;
                applied = 1;
                ok = true;
                if (hrBackdrop != 0) Log.Write("note: backdrop 'none' returned 0x" + hrBackdrop.ToString("X") + " (fine on Windows 10)");
            }
            else
            {
                // Windows refused the tint on this build/elevation: fall back to Acrylic so the
                // window never ends up solid by accident, and tell the user via the tooltip.
                Log.Write("see-through rejected (win32 error " + err + ") -> using Acrylic instead");
                _degraded = true;
                _tray.Text = TrayText();
                int hr = Native.SetBackdrop(hwnd, 3);
                applied = 3;
                ok = hr == 0;
            }
        }
        else
        {
            int backdrop = _style.IsClear ? 3 : _style.Backdrop;   // degraded see-through = Acrylic
            if (st.AccentOn)
            {
                Native.SetAccent(hwnd, Native.ACCENT_DISABLED, 0, out _);
                st.AccentOn = false;
            }
            int hr = Native.SetBackdrop(hwnd, backdrop);
            applied = backdrop;
            ok = hr == 0;
            if (!ok) Log.Write("set backdrop " + backdrop + " failed: 0x" + hr.ToString("X"));
        }

        st.Gen = _gen;
        st.AppliedBackdrop = applied;
        if (ok) { st.Failures = 0; }
        else
        {
            st.Failures++;
            _failed = true;
            _tray.Text = TrayText();
            Log.Write("apply failed for 0x" + hwnd.ToString("X") + " (" + st.Failures + "/" + MaxFailures
                      + "). If PowerToys runs as administrator, RunAcrylic must run elevated too.");
        }
        if (ok && _failed) { _failed = false; _tray.Text = TrayText(); }
    }

    private void RestoreAll()
    {
        foreach (KeyValuePair<IntPtr, WinState> kv in _state)
        {
            if (kv.Value.Gen < 0 || !Native.IsWindow(kv.Key)) continue;
            try
            {
                if (kv.Value.AccentOn) Native.SetAccent(kv.Key, Native.ACCENT_DISABLED, 0, out _);
                Native.SetBackdrop(kv.Key, kv.Value.Orig);
                Log.Write("restored 0x" + kv.Key.ToString("X") + " (backdrop " + kv.Value.Orig + ")");
            }
            catch (Exception ex) { Log.Write("restore failed: " + ex.Message); }
        }
        _state.Clear();
    }

    // =========================================================================================
    //  tray menu
    // =========================================================================================

    private void AddStyle(ContextMenuStrip menu, string arg)
    {
        StyleSpec s = StyleSpec.Parse(arg);
        var item = new ToolStripMenuItem(s.Name) { Tag = s };
        item.Click += (_, _) => ChangeStyle(s);
        _styleItems.Add(item);
        menu.Items.Add(item);
    }

    private void RefreshChecks()
    {
        foreach (ToolStripMenuItem item in _styleItems)
            item.Checked = item.Tag is StyleSpec s && s == _style;
    }

    private void ChangeStyle(StyleSpec s)
    {
        _style = s;
        _degraded = false;   // try the new choice honestly once
        _failed = false;
        _gen++;
        StyleSpec.Save(s.Arg);
        _tray.Text = TrayText();
        RefreshChecks();
        Log.Write("style changed to " + s.Name);

        if (s.IsOff) RestoreAll();
        else ScanAndApply();
        Native.TrimWorkingSet();
    }

    private string TrayText()
    {
        string t = "RunAcrylic: " + _style.Name;
        if (_degraded) t = "RunAcrylic: Acrylic (see-through unavailable)";
        else if (_failed) t += " (not applied, see log)";
        return t.Length > 63 ? t.Substring(0, 63) : t;   // NotifyIcon text limit
    }

    private static void OpenLog()
    {
        try { Process.Start(new ProcessStartInfo(Log.FilePath) { UseShellExecute = true })?.Dispose(); }
        catch (Exception ex) { Log.Write("open log failed: " + ex.Message); }
    }

    private static Icon LoadIcon()
    {
        try
        {
            using Stream? s = Assembly.GetExecutingAssembly().GetManifestResourceStream("RunAcrylic.ico");
            if (s != null) return new Icon(s, SystemInformation.SmallIconSize);   // best size for this DPI
        }
        catch (Exception ex) { Log.Write("icon load failed: " + ex.Message); }
        return SystemIcons.Application;
    }

    // =========================================================================================
    //  shutdown
    // =========================================================================================

    private bool ParentAlive()
    {
        try
        {
            using Process p = Process.GetProcessById((int)_parentPid);
            return !p.HasExited;
        }
        catch (ArgumentException) { return false; }   // no such process
        catch { return true; }                        // cannot tell: assume alive
    }

    private void ExitApp()
    {
        if (_exiting) return;
        _exiting = true;
        try
        {
            SystemEvents.UserPreferenceChanged -= OnUserPreferenceChanged;
            SystemEvents.PowerModeChanged -= OnPowerModeChanged;
            SystemEvents.SessionSwitch -= OnSessionSwitch;
            if (_hookLife != IntPtr.Zero) { Native.UnhookWinEvent(_hookLife); _hookLife = IntPtr.Zero; }
            if (_hookName != IntPtr.Zero) { Native.UnhookWinEvent(_hookName); _hookName = IntPtr.Zero; }
            _watchdog?.Stop();
            _poll?.Stop();
            _settle?.Stop();
            _debounce?.Stop();
            RestoreAll();             // harmless if PowerToys Run is already gone
            _tray.Visible = false;    // remove the icon immediately, no ghost icon
            _tray.Dispose();
            _icon.Dispose();
            _parent.Dispose();
            Log.Write("exit");
        }
        catch (Exception ex) { Log.Write("exit error: " + ex.Message); }
        ExitThread();
    }
}
