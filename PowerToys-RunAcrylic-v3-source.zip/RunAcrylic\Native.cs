using System;
using System.Runtime.InteropServices;
using System.Text;

internal static class Native
{
    // ---- WinEvent hook ----------------------------------------------------------------------
    public const int OBJID_WINDOW = 0;
    public const uint EVENT_OBJECT_CREATE = 0x8000;
    public const uint EVENT_OBJECT_DESTROY = 0x8001;
    public const uint EVENT_OBJECT_SHOW = 0x8002;
    public const uint EVENT_OBJECT_HIDE = 0x8003;
    public const uint EVENT_OBJECT_NAMECHANGE = 0x800C;
    public const uint WINEVENT_OUTOFCONTEXT = 0x0000;

    public delegate void WinEventProc(IntPtr hook, uint evt, IntPtr hwnd, int idObject, int idChild, uint thread, uint time);
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern IntPtr SetWinEventHook(uint eventMin, uint eventMax, IntPtr hmodWinEventProc,
        WinEventProc proc, uint idProcess, uint idThread, uint flags);

    [DllImport("user32.dll")]
    public static extern bool UnhookWinEvent(IntPtr hook);

    // ---- window queries ---------------------------------------------------------------------
    [DllImport("user32.dll")]
    public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int maxCount);

    [DllImport("user32.dll")]
    public static extern bool IsWindow(IntPtr hWnd);

    // ---- DWM --------------------------------------------------------------------------------
    public const int DWMWA_SYSTEMBACKDROP_TYPE = 38;

    [DllImport("dwmapi.dll")]
    public static extern int DwmGetWindowAttribute(IntPtr hwnd, int attr, out int value, int size);

    [DllImport("dwmapi.dll")]
    public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

    [DllImport("dwmapi.dll")]
    public static extern int DwmExtendFrameIntoClientArea(IntPtr hwnd, ref MARGINS margins);

    [StructLayout(LayoutKind.Sequential)]
    public struct MARGINS { public int Left, Right, Top, Bottom; }

    /// <summary>Current DWM backdrop type of the window, or -1 if it cannot be read.</summary>
    public static int GetBackdrop(IntPtr hwnd)
    {
        int hr = DwmGetWindowAttribute(hwnd, DWMWA_SYSTEMBACKDROP_TYPE, out int v, sizeof(int));
        return hr == 0 ? v : -1;
    }

    public static int SetBackdrop(IntPtr hwnd, int type)
    {
        int t = type;
        return DwmSetWindowAttribute(hwnd, DWMWA_SYSTEMBACKDROP_TYPE, ref t, sizeof(int));
    }

    // ---- accent policy (translucent tint) ---------------------------------------------------
    // Undocumented but widely used (TranslucentTB etc.). Used only for the "See-through" styles.
    public const int ACCENT_DISABLED = 0;
    public const int ACCENT_ENABLE_TRANSPARENTGRADIENT = 2;
    private const int WCA_ACCENT_POLICY = 19;

    [StructLayout(LayoutKind.Sequential)]
    private struct AccentPolicy { public int AccentState; public int AccentFlags; public uint GradientColor; public int AnimationId; }

    [StructLayout(LayoutKind.Sequential)]
    private struct WindowCompositionAttributeData { public int Attribute; public IntPtr Data; public int SizeOfData; }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern int SetWindowCompositionAttribute(IntPtr hWnd, ref WindowCompositionAttributeData data);

    public static bool SetAccent(IntPtr hwnd, int state, uint color, out int win32Error)
    {
        var policy = new AccentPolicy { AccentState = state, AccentFlags = 2, GradientColor = color, AnimationId = 0 };
        int size = Marshal.SizeOf<AccentPolicy>();
        IntPtr ptr = Marshal.AllocHGlobal(size);
        try
        {
            Marshal.StructureToPtr(policy, ptr, false);
            var data = new WindowCompositionAttributeData { Attribute = WCA_ACCENT_POLICY, Data = ptr, SizeOfData = size };
            int r = SetWindowCompositionAttribute(hwnd, ref data);
            win32Error = r != 0 ? 0 : Marshal.GetLastWin32Error();
            return r != 0;
        }
        finally { Marshal.FreeHGlobal(ptr); }
    }

    // ---- memory -----------------------------------------------------------------------------
    [DllImport("kernel32.dll")]
    private static extern IntPtr GetCurrentProcess();

    [DllImport("kernel32.dll")]
    private static extern bool SetProcessWorkingSetSize(IntPtr process, IntPtr min, IntPtr max);

    /// <summary>Hands unused pages back to Windows (the idle footprint then shows in Task Manager).</summary>
    public static void TrimWorkingSet()
    {
        try
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            SetProcessWorkingSetSize(GetCurrentProcess(), new IntPtr(-1), new IntPtr(-1));
        }
        catch { /* cosmetic */ }
    }
}
