using System;
using System.IO;

/// <summary>
/// Tiny file logger: %LOCALAPPDATA%\RunAcrylic\RunAcrylic.log, reset at every companion start,
/// capped at 256 KB so it can never grow without bound. Only state changes are logged
/// (never per-event), so logging costs nothing in the hot path.
/// </summary>
internal static class Log
{
    private const long MaxChars = 256 * 1024;
    private static readonly object Gate = new object();
    private static long _written;
    private static bool _capped;

    public static string Dir =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RunAcrylic");

    public static string FilePath => Path.Combine(Dir, "RunAcrylic.log");

    public static void Reset()
    {
        lock (Gate)
        {
            _written = 0;
            _capped = false;
            try
            {
                Directory.CreateDirectory(Dir);
                File.WriteAllText(FilePath, string.Empty);
            }
            catch { /* logging must never break the app */ }
        }
    }

    public static void Write(string message)
    {
        lock (Gate)
        {
            if (_capped) return;
            try
            {
                string line = DateTime.Now.ToString("HH:mm:ss.fff ") + message + Environment.NewLine;
                _written += line.Length;
                if (_written > MaxChars)
                {
                    _capped = true;
                    line = "... log size cap reached, further lines are dropped" + Environment.NewLine;
                }
                File.AppendAllText(FilePath, line);
            }
            catch { /* ignore */ }
        }
    }
}
