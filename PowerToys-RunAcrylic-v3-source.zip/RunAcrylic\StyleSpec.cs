using System;
using System.IO;

/// <summary>
/// One selectable look for the PowerToys Run window.
/// Backdrop: DWM system backdrop type (1 none, 2 mica, 3 acrylic); -1 = Off (do not touch the window).
/// Opacity:  255 = fully opaque. Below 255 (only with backdrop 1) a translucent dark tint is used.
/// Arg:      the text that is saved to style.txt and accepted on the command line.
/// </summary>
internal readonly record struct StyleSpec(string Name, int Backdrop, byte Opacity, string Arg)
{
    public bool IsOff => Backdrop < 0;

    /// <summary>"See-through": no blur, translucent dark tint (accent policy).</summary>
    public bool IsClear => Backdrop == 1 && Opacity < 255;

    public static StyleSpec Parse(string? arg)
    {
        string a = (arg ?? string.Empty).Trim().ToLowerInvariant();

        if (a == "off") return new StyleSpec("Off (PowerToys default)", -1, 255, "off");
        if (a == "acrylic") return new StyleSpec("Acrylic (frosted)", 3, 255, "acrylic");
        if (a == "mica") return new StyleSpec("Mica", 2, 255, "mica");

        if (a == "clear") a = "clear:75";
        if (a.StartsWith("clear:", StringComparison.Ordinal)
            && int.TryParse(a.AsSpan(6), out int pct))
        {
            pct = Math.Clamp(pct, 10, 100);
            return new StyleSpec("See-through " + pct + "%", 1, (byte)Math.Round(pct * 255 / 100.0), "clear:" + pct);
        }

        // Unknown text (typo, corrupted style.txt) -> safe default.
        return new StyleSpec("See-through 75%", 1, 191, "clear:75");
    }

    // ---- persisted choice -------------------------------------------------------------------

    private static string SettingsFile => Path.Combine(Log.Dir, "style.txt");

    public static string? LoadSaved()
    {
        try { return File.Exists(SettingsFile) ? File.ReadAllText(SettingsFile).Trim() : null; }
        catch { return null; }
    }

    public static void Save(string arg)
    {
        try
        {
            Directory.CreateDirectory(Log.Dir);
            string tmp = SettingsFile + ".tmp";
            File.WriteAllText(tmp, arg);
            File.Move(tmp, SettingsFile, overwrite: true);   // atomic replace, no half-written file
        }
        catch { /* not critical */ }
    }
}
